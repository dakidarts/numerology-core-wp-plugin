<?php
/**
 * Dakidarts Numerology Core - Shortcodes (POST)
 *
 * Registers and handles shortcodes for displaying Numerology forms/results using POST requests.
 *
 * @package Dakidarts_Numerology_Core
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Dakidarts_Shortcodes {

    /**
     * Constructor.
     */
    public function __construct() {
        add_action( 'init', [ $this, 'register_shortcodes' ] );
    }

    /**
     * Register the main shortcode.
     *
     * Example: [dakidarts_numerology endpoint="life-path"]
     */
    public function register_shortcodes() {
        add_shortcode( 'dakidarts_numerology', [ $this, 'render_shortcode' ] );
    }

    /**
     * Handle shortcode rendering.
     *
     * @param array $atts Shortcode attributes.
     * @return string
     */
    public function render_shortcode( $atts ) {
        $atts = shortcode_atts(
            [
                'endpoint' => 'life-path', // Default endpoint
                'template' => 'default',   // Template name
            ],
            $atts,
            'dakidarts_numerology'
        );

        $endpoint = sanitize_key( $atts['endpoint'] );
        $template = sanitize_key( $atts['template'] );

        $endpoints = Dakidarts_API::get_endpoints();
        if ( ! isset( $endpoints[ $endpoint ] ) ) {
            return '<p>' . esc_html__( 'Invalid Numerology endpoint.', 'dakidarts-numerology-core' ) . '</p>';
        }

        // Handle POST submission
        if ( isset( $_POST['dakidarts_submit'] ) && isset( $_POST['dakidarts_endpoint'] ) && sanitize_key( $_POST['dakidarts_endpoint'] ) === $endpoint ) {

            $params = [];
            foreach ( $endpoints[ $endpoint ]['params'] as $param ) {
                if ( isset( $_POST[ $param ] ) ) {
                    $value = sanitize_text_field( wp_unslash( $_POST[ $param ] ) );

                    // Cast numeric fields for endpoints that require integers
                    $numeric_endpoints = ['life-path', 'karmic-lesson', 'karmic-debt'];
                    if ( in_array($endpoint, $numeric_endpoints) && in_array($param, ['year','month','day']) ) {
                        $value = (int) $value;
                    }

                    $params[ $param ] = $value;
                }
            }

            $response = Dakidarts_API::request( $endpoint, $params );

            if ( is_wp_error( $response ) ) {
                return '<p class="dakidarts-error">' . esc_html( $response->get_error_message() ) . '</p>';
            }

            if ( class_exists( 'Dakidarts_Render' ) ) {
                return Dakidarts_Render::render_result( $response, $template );
            }

            return '<pre>' . esc_html( print_r( $response, true ) ) . '</pre>';
        }

        // Render input form
        if ( class_exists( 'Dakidarts_Render' ) ) {
            return Dakidarts_Render::render_form( $endpoint, $endpoints[ $endpoint ]['params'], $template );
        }

        return '<p>' . esc_html__( 'Form renderer not available.', 'dakidarts-numerology-core' ) . '</p>';
    }
}
