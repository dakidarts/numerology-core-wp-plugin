<?php
/**
 * Dakidarts Numerology Core - Admin
 *
 * Handles admin pages: Welcome, Settings, Style
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class Dakidarts_Admin {

    private $welcome;
    private $settings;
    private $style;

    public function __construct() {
        // Register admin menus
        add_action( 'admin_menu', [ $this, 'register_admin_menu' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_assets' ] );

        // Load subpage classes
        require_once plugin_dir_path( __FILE__ ) . 'admin/class-dakidarts-admin-welcome.php';
        require_once plugin_dir_path( __FILE__ ) . 'admin/class-dakidarts-admin-settings.php';
        require_once plugin_dir_path( __FILE__ ) . 'admin/class-dakidarts-admin-style.php';

        $this->welcome  = new Dakidarts_Admin_Welcome();
        $this->settings = new Dakidarts_Admin_Settings();
        $this->style    = new Dakidarts_Admin_Style();
    }

    public function register_admin_menu() {
    // Main menu → top-level menu
    add_menu_page(
        __( 'Dakidarts Numerology', 'dakidarts-numerology-core' ),
        __( 'Numerology', 'dakidarts-numerology-core' ),
        'manage_options',
        'dakidarts-numerology', // main slug
        '', // no callback here
        DAKIDARTS_PLUGIN_URL . 'assets/images/dashicon.png', // custom PNG icon
        59
    );

    // Submenus
    add_submenu_page(
        'dakidarts-numerology',
        __( 'Welcome', 'dakidarts-numerology-core' ),
        __( 'Welcome', 'dakidarts-numerology-core' ),
        'manage_options',
        'dakidarts-numerology', 
        [ $this->welcome, 'render' ]
    );
    add_submenu_page(
        'dakidarts-numerology',
        __( 'Settings', 'dakidarts-numerology-core' ),
        __( 'Settings', 'dakidarts-numerology-core' ),
        'manage_options',
        'dakidarts-numerology-settings',
        [ $this->settings, 'render' ]
    );
    add_submenu_page(
        'dakidarts-numerology',
        __( 'Style', 'dakidarts-numerology-core' ),
        __( 'Style', 'dakidarts-numerology-core' ),
        'manage_options',
        'dakidarts-numerology-style',
        [ $this->style, 'render' ]
    );

    // Inject inline CSS for PNG icon styling
    add_action('admin_head', function() {
        echo '<style>
            #adminmenu #toplevel_page_dakidarts-numerology .wp-menu-image img {
                padding: 6px 0 0;
                width: 20px; /* adjust width if needed */
                height: 20px; /* adjust height if needed */
            }
        </style>';
    });
}



    public function enqueue_admin_assets( $hook ) {
        if ( strpos( $hook, 'dakidarts-numerology' ) === false ) return;

        wp_enqueue_style(
            'dakidarts-admin-css',
            plugins_url( '../assets/css/admin.css', __FILE__ ),
            [],
            filemtime( plugin_dir_path( __FILE__ ) . '../assets/css/admin.css' )
        );

        wp_enqueue_script(
            'dakidarts-admin-js',
            plugins_url( '../assets/js/admin.js', __FILE__ ),
            [ 'jquery' ],
            filemtime( plugin_dir_path( __FILE__ ) . '../assets/js/admin.js' ),
            true
        );
    }
}

// Initialize admin
new Dakidarts_Admin();
