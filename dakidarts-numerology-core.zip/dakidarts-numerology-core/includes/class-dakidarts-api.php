<?php
/**
 * Dakidarts Numerology Core - API Wrapper
 *
 * Handles all communication with the Numerology API via RapidAPI using POST requests.
 *
 * @package Dakidarts_Numerology_Core
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Dakidarts_API {

    private static $base_url = 'https://the-numerology-api.p.rapidapi.com';

    private static $endpoints = [
    'life-path' => [
        'path' => '/life_path/post',
        'params' => [ 'birth_year', 'birth_month', 'birth_day' ],
        'param_desc' => [
            'birth_year'  => 'Year of Birth (YYYY)',
            'birth_month' => 'Month of Birth (01-12)',
            'birth_day'   => 'Day of Birth (01-31)'
        ],
        'label' => 'Life Path'
    ],
    'sun-number' => [
        'path' => '/attitude_number/post',
        'params' => [ 'birth_day', 'birth_month' ],
        'param_desc' => [
            'birth_day'   => 'Day of Birth (01-31)',
            'birth_month' => 'Month of Birth (01-12)'
        ],
        'label' => 'Sun Number'
    ],
    'challenge-number' => [
        'path' => '/challenge_number/post',
        'params' => [ 'birth_day', 'birth_month', 'birth_year' ],
        'param_desc' => [
            'birth_day'   => 'Day of Birth (01-31)',
            'birth_month' => 'Month of Birth (01-12)',
            'birth_year'  => 'Year of Birth (YYYY)'
        ],
        'label' => 'Challenge Number'
    ],
    'karmic-debt' => [
        'path' => '/karmic_debt/post',
        'params' => [ 'birth_year', 'birth_month', 'birth_day' ],
        'param_desc' => [
            'birth_year'  => 'Year of Birth (YYYY)',
            'birth_month' => 'Month of Birth (01-12)',
            'birth_day'   => 'Day of Birth (01-31)'
        ],
        'label' => 'Karmic Debt'
    ],
    'karmic-lesson' => [
        'path' => '/karmic_lessons/post',
        'params' => [ 'full_name' ],
        'param_desc' => [
            'full_name' => 'Full Name as on Birth Certificate'
        ],
        'label' => 'Karmic Lesson'
    ],
    'personality-number' => [
        'path' => '/personality_number/post',
        'params' => [ 'first_name', 'middle_name', 'last_name' ],
        'param_desc' => [
            'first_name'  => 'First Name',
            'middle_name' => 'Middle Name (optional)',
            'last_name'   => 'Last Name'
        ],
        'label' => 'Personality Number'
    ],
    'personal-year' => [
        'path' => '/personal_year/post',
        'params' => [ 'prediction_year', 'birth_month', 'birth_day' ],
        'param_desc' => [
            'prediction_year' => 'Year for Prediction (YYYY)',
            'birth_month'     => 'Month of Birth (01-12)',
            'birth_day'       => 'Day of Birth (01-31)'
        ],
        'label' => 'Personal Year'
    ],
    'personal-month' => [
        'path' => '/personal-month',
        'params' => [ 'dob' ],
        'param_desc' => [
            'dob' => 'Date of Birth (YYYY-MM-DD)'
        ],
        'label' => 'Personal Month'
    ],
    'personal-day' => [
        'path' => '/personal-day',
        'params' => [ 'dob' ],
        'param_desc' => [
            'dob' => 'Date of Birth (YYYY-MM-DD)'
        ],
        'label' => 'Personal Day'
    ],
    'phone-number' => [
        'path' => '/analyze_phone/post',
        'params' => [ 'phone_number' ],
        'param_desc' => [
            'phone_number' => 'Phone Number with Country Code (e.g., +1234567890)'
        ],
        'label' => 'Phone Number'
    ],
    'soul-expression' => [
        'path' => '/destiny_number/post',
        'params' => [ 'first_name', 'middle_name', 'last_name' ],
        'param_desc' => [
            'first_name'  => 'First Name',
            'middle_name' => 'Middle Name (optional)',
            'last_name'   => 'Last Name'
        ],
        'label' => 'Soul Expression'
    ],
    'soul-urge' => [
        'path' => '/heart_desire/post',
        'params' => [ 'first_name', 'middle_name', 'last_name' ],
        'param_desc' => [
            'first_name'  => 'First Name',
            'middle_name' => 'Middle Name (optional)',
            'last_name'   => 'Last Name'
        ],
        'label' => 'Soul Urge'
    ],
    'subconscious-self' => [
        'path' => '/subconscious_number/post',
        'params' => [ 'name' ],
        'param_desc' => [
            'name' => 'Full Name to Analyze'
        ],
        'label' => 'Subconscious Number'
    ],
    'balance-number' => [
        'path' => '/balance_number/post',
        'params' => [ 'initials' ],
        'param_desc' => [
            'initials' => 'Initials of Full Name'
        ],
        'label' => 'Balance Number'
    ],
    'lucky-numbers' => [
        'path' => '/lucky_numbers/post',
        'params' => [ 'birthdate', 'name' ],
        'param_desc' => [
            'birthdate' => 'Date of Birth (YYYY-MM-DD)',
            'name'      => 'Full Name'
        ],
        'label' => 'Lucky Numbers'
    ],
    'rational-thought' => [
        'path' => '/thought_number/post',
        'params' => [ 'first_name', 'birth_day' ],
        'param_desc' => [
            'first_name' => 'First Name',
            'birth_day'  => 'Day of Birth (01-31)'
        ],
        'label' => 'Rational Thought'
    ],
    'life-period' => [
        'path' => '/period_cycles/post',
        'params' => [ 'birth_year', 'birth_month', 'birth_day' ],
        'param_desc' => [
            'birth_year'  => 'Year of Birth (YYYY)',
            'birth_month' => 'Month of Birth (01-12)',
            'birth_day'   => 'Day of Birth (01-31)'
        ],
        'label' => 'Life Period Cycles'
    ]
];


    /**
     * Get endpoints with labels
     */
    public static function get_endpoints() {
        return apply_filters( 'dakidarts_numerology_endpoints', self::$endpoints );
    }

    /**
     * Make an API POST request
     */
    public static function request( $endpoint_key, $params = [] ) {
        $endpoints = self::get_endpoints();

        if ( ! isset( $endpoints[ $endpoint_key ] ) ) {
            return new WP_Error( 'invalid_endpoint', __( 'Invalid API endpoint requested.', 'dakidarts-numerology-core' ) );
        }

        $endpoint = $endpoints[ $endpoint_key ];

        // Validate required params
        foreach ( $endpoint['params'] as $p ) {
            if ( ! isset( $params[ $p ] ) || $params[ $p ] === '' ) {
                return new WP_Error( 'missing_param', sprintf( __( 'Missing required parameter: %s', 'dakidarts-numerology-core' ), $p ) );
            }
        }

        $url = rtrim( self::$base_url, '/' ) . '/' . ltrim( $endpoint['path'], '/' );

        $api_key = self::get_api_key();
        if ( ! $api_key ) {
            return new WP_Error( 'missing_api_key', __( 'API key not configured. Please set it in plugin settings.', 'dakidarts-numerology-core' ) );
        }

        $headers = [
            'x-rapidapi-host' => 'the-numerology-api.p.rapidapi.com',
            'x-rapidapi-key'  => $api_key,
            'Content-Type'    => 'application/json',
        ];

        $args = [
            'headers' => $headers,
            'timeout' => 20,
            'method'  => 'POST',
            'body'    => wp_json_encode( $params ),
        ];

        $response = wp_remote_post( $url, $args );

        if ( is_wp_error( $response ) ) {
            return new WP_Error( 'api_request_failed', __( 'API request failed.', 'dakidarts-numerology-core' ), $response->get_error_message() );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );

        $data = json_decode( $body, true );

        if ( $code < 200 || $code >= 300 ) {
            return new WP_Error( 'api_error', sprintf( __( 'API request failed with status %d.', 'dakidarts-numerology-core' ), $code ), $body );
        }

        return $data;
    }

    /**
     * Retrieve decrypted API key from settings
     */
    public static function get_api_key() {
        $options = get_option( 'dakidarts_numerology_core_settings', [] );

        if ( empty( $options['api_key'] ) ) {
            return false;
        }

        // Decrypt if helper exists
        if ( method_exists( 'Dakidarts_Helpers', 'decrypt' ) ) {
            $encryption_key = defined( 'DAKIDARTS_SECRET_KEY' ) ? DAKIDARTS_SECRET_KEY : '';
            return Dakidarts_Helpers::decrypt( $options['api_key'], $encryption_key );
        }

        return $options['api_key'];
    }
}
