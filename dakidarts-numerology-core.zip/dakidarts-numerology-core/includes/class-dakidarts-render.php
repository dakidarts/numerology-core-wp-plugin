<?php
/**
 * Dakidarts Numerology Core - Renderer
 *
 * Handles rendering of API results to the frontend
 * (via shortcodes, templates, or Gutenberg blocks),
 * applying admin-defined styles dynamically.
 *
 * @package Dakidarts_Numerology_Core
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Dakidarts_Render {

    // Keep track of rendered forms/buttons to prevent duplicates
    private static $rendered_forms = [];
    private static $rendered_buttons = [];

    /**
     * Get admin style settings
     *
     * @return array
     */
    private static function get_styles(): array {
        return get_option( 'dakidarts_numerology_style_settings', [] );
    }

    /**
     * Render a styled button
     *
     * @param string $text Button text
     * @param string $type HTML type attribute
     * @param string $id Optional unique ID to avoid duplicate
     * @return string
     */
    public static function render_button( string $text = 'Submit', string $type = 'submit', string $id = '' ): string {
        if ( $id && in_array( $id, self::$rendered_buttons, true ) ) {
            return ''; // Already rendered
        }
        if ( $id ) self::$rendered_buttons[] = $id;

        $styles = self::get_styles();
        $style_attr = '';

        $style_attr .= ! empty( $styles['button_bg'] ) ? 'background:' . esc_attr( $styles['button_bg'] ) . ';' : '';
        $style_attr .= ! empty( $styles['button_color'] ) ? 'color:' . esc_attr( $styles['button_color'] ) . ';' : '';
        $style_attr .= ! empty( $styles['button_padding'] ) ? 'padding:' . esc_attr( $styles['button_padding'] ) . ';' : '';
        $style_attr .= ! empty( $styles['button_margin'] ) ? 'margin:' . esc_attr( $styles['button_margin'] ) . ';' : '';
        $style_attr .= ! empty( $styles['button_radius'] ) ? 'border-radius:' . esc_attr( $styles['button_radius'] ) . ';' : '';

        if ( isset( $styles['button_border_width'], $styles['button_border_style'], $styles['button_border_color'] ) ) {
            $style_attr .= 'border:' . esc_attr( $styles['button_border_width'] ) . ' '
                . esc_attr( $styles['button_border_style'] ) . ' '
                . esc_attr( $styles['button_border_color'] ) . ';';
        }

        $position = $styles['button_position'] ?? 'inherit';
        if ( $position !== 'inherit' ) {
            $style_attr .= 'display:block;margin:0 auto;text-align:' . esc_attr( $position ) . ';';
        }

        return sprintf(
            '<button type="%1$s" style="%2$s">%3$s</button>',
            esc_attr( $type ),
            esc_attr( $style_attr ),
            esc_html( $text )
        );
    }

    /**
     * Render a form using a template file
     *
     * @param string $endpoint
     * @param array  $params
     * @param string $template
     * @param string $id Optional unique ID to prevent duplicates
     * @return string
     */
    public static function render_form( string $endpoint, array $params = [], string $template = 'default', string $id = '' ): string {
    if ( $id && in_array( $id, self::$rendered_forms, true ) ) {
        return ''; // Already rendered
    }
    if ( $id ) self::$rendered_forms[] = $id;

    $template_file = plugin_dir_path( __FILE__ ) . "../templates/form-{$template}.php";
    if ( ! file_exists( $template_file ) ) {
        $template_file = plugin_dir_path( __FILE__ ) . "../templates/form-default.php";
    }

    // Get param descriptions from API endpoints
    $endpoints = Dakidarts_API::get_endpoints();
    $param_desc = isset($endpoints[$endpoint]['param_desc']) ? $endpoints[$endpoint]['param_desc'] : [];

    ob_start();
    include $template_file;
    return ob_get_clean();
}


    /**
     * Render API result using a template file
     *
     * @param array  $response
     * @param string $template
     * @return string
     */
    public static function render_result( array $response, string $template = 'default' ): string {
        $template_file = plugin_dir_path( __FILE__ ) . "../templates/result-{$template}.php";
        if ( ! file_exists( $template_file ) ) {
            $template_file = plugin_dir_path( __FILE__ ) . "../templates/result-default.php";
        }

        ob_start();
        include $template_file;
        return ob_get_clean();
    }

}
