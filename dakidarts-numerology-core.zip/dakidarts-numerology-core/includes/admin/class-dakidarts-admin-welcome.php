<?php
/**
 * Dakidarts Numerology Core - Admin Welcome Page
 *
 * Displays a beautiful HTML welcome page in the admin dashboard.
 *
 * @package Dakidarts_Numerology_Core
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'Dakidarts_Admin_Welcome' ) ) {

    class Dakidarts_Admin_Welcome {

        /**
         * Constructor.
         */
        public function __construct() {
            add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
        }

        /**
         * Enqueue CSS/JS for the welcome page.
         */
        public function enqueue_assets( $hook ) {
            // Only enqueue on our plugin admin page
            if ( strpos( $hook, 'dakidarts-numerology-core' ) === false ) {
                return;
            }

            $css_file = DAKIDARTS_PLUGIN_URL . 'assets/css/admin.css';
            $js_file  = DAKIDARTS_PLUGIN_URL . 'assets/js/admin.js';

            wp_enqueue_style(
                'dakidarts-admin-welcome',
                $css_file,
                [],
                file_exists( $css_file ) ? filemtime( $css_file ) : null
            );

            wp_enqueue_script(
                'dakidarts-admin-welcome-js',
                $js_file,
                [ 'jquery' ],
                file_exists( $js_file ) ? filemtime( $js_file ) : null,
                true
            );
        }

        /**
         * Render the welcome HTML content.
         */
        /**
 * Render the welcome HTML content.
 */
public function render() {
    $icon_url = DAKIDARTS_PLUGIN_URL . 'assets/images/icon.jpg';
    $api_doc_link = 'https://dakidarts.com/plugin/numerology-wordpress-plugin/';
    $rapidapi_sub_link = 'https://rapidapi.com/dakidarts-dakidarts-default/api/the-numerology-api';
    ?>
    <div class="dakidarts-admin-welcome">
        <div class="welcome-header" style="text-align:center; padding:30px;">
            <img src="<?php echo esc_url($icon_url); ?>" alt="Dakidarts Logo" style="width:80px; height:auto; margin-bottom:20px; border-radius:14px;">
            <h1 style="font-size:2.2em; margin-bottom:10px;">✨ Welcome to Dakidarts Numerology</h1>
            <p style="font-size:1.1em; color:#555; padding: 17px 170px;">
    Unlock the full power of numerology in WordPress. Use shortcodes, Gutenberg blocks, and fully customizable forms — all built on the <strong>Dakidarts Numerology API</strong>. 
    This means accurate, real-time calculations directly connected to our powerful API engine, with options to extend usage through RapidAPI for advanced integrations.
</p>

        </div>

        <div class="welcome-links" style="display:flex; justify-content:center; gap:20px; margin-top:30px;">
            <a href="<?php echo esc_url($api_doc_link); ?>" target="_blank" class="button button-primary" style="padding:12px 25px;">Plugin Highlights</a>
            <a href="<?php echo esc_url($rapidapi_sub_link); ?>" target="_blank" class="button button-secondary" style="padding:12px 25px;">Get Your API Key</a>
        </div>

        <div class="welcome-features" style="margin-top:50px; display:grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap:20px; margin-right: 20px;">
            <?php foreach ($this->getFeatures() as $feature): ?>
                <a href="<?php echo esc_url($feature['url']); ?>" target="_blank" style="text-decoration:none; color:inherit;">
                    <div class="feature-card" style="background:#f9f9f9; padding:20px; border-radius:8px; text-align:center; box-shadow:0 2px 6px rgba(0,0,0,0.1); transition:transform 0.2s;">
                        <img src="<?php echo esc_url(DAKIDARTS_PLUGIN_URL . 'assets/images/' . $feature['icon']); ?>" alt="<?php echo esc_attr($feature['title']); ?>" style="width:260px; height:auto; margin-bottom:8px; border-radius:12px;">
                        <h3><?php echo esc_html($feature['title']); ?></h3>
                        <p><?php echo esc_html($feature['description']); ?></p>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
    <?php
}

/**
 * Get the features for the welcome page.
 *
 * @return array Array of feature arrays.
 */
private function getFeatures() {
    return [
        [
            'title' => 'Shortcodes',
            'description' => 'Quickly insert numerology forms anywhere using simple shortcodes.',
            'icon' => 'shortcodes.jpg',
            'url'  => esc_url( add_query_arg( 'page', 'dakidarts-numerology-settings', admin_url( 'admin.php' ) ) ),
        ],
        [
            'title' => 'Gutenberg Blocks',
            'description' => 'Add interactive numerology blocks to your posts and pages with ease.',
            'icon' => 'blocks.jpg',
            'url'  => 'https://hub.dakidarts.com/getting-started-with-dakidarts-numerology-wordpress-plugin/', // Custom URL to be added later
        ],
        [
            'title' => 'Fully Customizable',
            'description' => 'Change colors, sizes, padding, margins, buttons, and form styles directly from the admin panel.',
            'icon' => 'customizable.jpg',
            'url'  => esc_url( add_query_arg( 'page', 'dakidarts-numerology-style', admin_url( 'admin.php' ) ) ),
        ],
    ];
}

}
}
