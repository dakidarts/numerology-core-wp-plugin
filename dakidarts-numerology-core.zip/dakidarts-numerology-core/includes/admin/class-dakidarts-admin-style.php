<?php
/**
 * Dakidarts Numerology Core - Admin Style Customizations
 *
 * Allows admins to customize frontend form and button styles.
 *
 * @package Dakidarts_Numerology_Core
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Dakidarts_Admin_Style {

    private $option_key = 'dakidarts_numerology_style_settings';

    public function __construct() {
        add_action( 'admin_menu', [ $this, 'add_admin_submenu' ] );
        add_action( 'admin_init', [ $this, 'register_settings' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_color_picker' ] ); // enqueue color picker
    }

    /**
     * Add submenu page under main plugin menu
     */
    public function add_admin_submenu() {
        add_submenu_page(
            'dakidarts-numerology-core',
            __( 'Style & Customization', 'dakidarts-numerology-core' ),
            __( 'Style', 'dakidarts-numerology-core' ),
            'manage_options',
            'dakidarts-admin-style',
            [ $this, 'render' ]
        );
    }

    /**
     * Enqueue WP color picker assets
     */
    public function enqueue_color_picker( $hook_suffix ) {
        // Only enqueue on our plugin style page
        if ( $hook_suffix !== 'dakidarts-numerology-core_page_dakidarts-admin-style' ) {
            return;
        }

        wp_enqueue_style( 'wp-color-picker' );
        wp_enqueue_script( 'wp-color-picker' );
    }

    /**
     * Register settings group
     */
    public function register_settings() {
        register_setting(
            'dakidarts_style_group',
            $this->option_key,
            [ $this, 'sanitize_settings' ]
        );
    }

    /**
 * Sanitize admin inputs
 */
public function sanitize_settings( $input ) {
    $sanitized = [];

    // Colors
    $color_keys = ['form_bg', 'button_bg', 'button_color', 'button_border_color'];
    foreach ( $color_keys as $key ) {
        $sanitized[ $key ] = isset( $input[ $key ] ) ? sanitize_hex_color( $input[ $key ] ) : '';
    }

    // Sizes & Spacing + Texts
    $text_keys = [
        'form_padding', 'button_padding', 'form_margin', 'button_margin',
        'button_radius', 'button_border_width',
        'calculate_text', 'try_again_text' // ✅ NEW
    ];
    foreach ( $text_keys as $key ) {
        $sanitized[ $key ] = isset( $input[ $key ] ) ? sanitize_text_field( $input[ $key ] ) : '';
    }

    // Button border style (must be valid CSS border style)
    $valid_styles = ['solid','dashed','dotted','double','groove','ridge','none'];
    $sanitized['button_border_style'] = isset( $input['button_border_style'] ) && in_array( $input['button_border_style'], $valid_styles, true )
        ? $input['button_border_style']
        : 'solid';

    // Button position
    $valid_positions = ['inherit','left','center','right'];
    $sanitized['button_position'] = isset( $input['button_position'] ) && in_array( $input['button_position'], $valid_positions, true )
        ? $input['button_position']
        : 'inherit';

    return $sanitized;
}

/**
 * Render admin page
 */
public function render() {
    $options = get_option( $this->option_key, [] );
    ?>
    <div class="wrap">
        <h1><?php esc_html_e( 'Style & Customization', 'dakidarts-numerology-core' ); ?></h1>
        <form method="post" action="options.php">
            <?php settings_fields( 'dakidarts_style_group' ); ?>
            <table class="form-table">
                <tbody>
                    <!-- ✅ Existing Fields (colors, borders, margins, etc.) -->

                    <tr>
                        <th><?php esc_html_e( 'Form Background Color', 'dakidarts-numerology-core' ); ?></th>
                        <td>
                            <input type="text"
                                   class="dakidarts-color-picker"
                                   name="<?php echo esc_attr($this->option_key); ?>[form_bg]"
                                   value="<?php echo esc_attr($options['form_bg'] ?? ''); ?>" />
                        </td>
                    </tr>

                    <tr>
                        <th><?php esc_html_e( 'Button Background Color', 'dakidarts-numerology-core' ); ?></th>
                        <td>
                            <input type="text"
                                   class="dakidarts-color-picker"
                                   name="<?php echo esc_attr($this->option_key); ?>[button_bg]"
                                   value="<?php echo esc_attr($options['button_bg'] ?? ''); ?>" />
                        </td>
                    </tr>

                    <tr>
                        <th><?php esc_html_e( 'Button Text Color', 'dakidarts-numerology-core' ); ?></th>
                        <td>
                            <input type="text"
                                   class="dakidarts-color-picker"
                                   name="<?php echo esc_attr($this->option_key); ?>[button_color]"
                                   value="<?php echo esc_attr($options['button_color'] ?? ''); ?>" />
                        </td>
                    </tr>

                    <tr>
                        <th><?php esc_html_e( 'Button Border Color', 'dakidarts-numerology-core' ); ?></th>
                        <td>
                            <input type="text"
                                   class="dakidarts-color-picker"
                                   name="<?php echo esc_attr($this->option_key); ?>[button_border_color]"
                                   value="<?php echo esc_attr($options['button_border_color'] ?? ''); ?>" />
                        </td>
                    </tr>

                    <tr>
                        <th><?php esc_html_e( 'Form Padding (px)', 'dakidarts-numerology-core' ); ?></th>
                        <td>
                            <input type="number"
                                   name="<?php echo esc_attr($this->option_key); ?>[form_padding]"
                                   value="<?php echo esc_attr($options['form_padding'] ?? ''); ?>" />
                        </td>
                    </tr>

                    <tr>
                        <th><?php esc_html_e( 'Button Padding (px)', 'dakidarts-numerology-core' ); ?></th>
                        <td>
                            <input type="number"
                                   name="<?php echo esc_attr($this->option_key); ?>[button_padding]"
                                   value="<?php echo esc_attr($options['button_padding'] ?? ''); ?>" />
                        </td>
                    </tr>

                    <tr>
                        <th><?php esc_html_e( 'Form Margin (px)', 'dakidarts-numerology-core' ); ?></th>
                        <td>
                            <input type="number"
                                   name="<?php echo esc_attr($this->option_key); ?>[form_margin]"
                                   value="<?php echo esc_attr($options['form_margin'] ?? ''); ?>" />
                        </td>
                    </tr>

                    <tr>
                        <th><?php esc_html_e( 'Button Margin (px)', 'dakidarts-numerology-core' ); ?></th>
                        <td>
                            <input type="number"
                                   name="<?php echo esc_attr($this->option_key); ?>[button_margin]"
                                   value="<?php echo esc_attr($options['button_margin'] ?? ''); ?>" />
                        </td>
                    </tr>

                    <tr>
                        <th><?php esc_html_e( 'Button Radius (px)', 'dakidarts-numerology-core' ); ?></th>
                        <td>
                            <input type="number"
                                   name="<?php echo esc_attr($this->option_key); ?>[button_radius]"
                                   value="<?php echo esc_attr($options['button_radius'] ?? ''); ?>" />
                        </td>
                    </tr>

                    <tr>
                        <th><?php esc_html_e( 'Button Border Width (px)', 'dakidarts-numerology-core' ); ?></th>
                        <td>
                            <input type="number"
                                   name="<?php echo esc_attr($this->option_key); ?>[button_border_width]"
                                   value="<?php echo esc_attr($options['button_border_width'] ?? ''); ?>" />
                        </td>
                    </tr>

                    <tr>
                        <th><?php esc_html_e( 'Button Border Style', 'dakidarts-numerology-core' ); ?></th>
                        <td>
                            <select name="<?php echo esc_attr($this->option_key); ?>[button_border_style]">
                                <?php
                                $styles = ['solid','dashed','dotted','double','groove','ridge','none'];
                                foreach ( $styles as $style ) {
                                    printf(
                                        '<option value="%s" %s>%s</option>',
                                        esc_attr($style),
                                        selected( $options['button_border_style'] ?? 'solid', $style, false ),
                                        esc_html( ucfirst($style) )
                                    );
                                }
                                ?>
                            </select>
                        </td>
                    </tr>

                    <tr>
                        <th><?php esc_html_e( 'Button Position', 'dakidarts-numerology-core' ); ?></th>
                        <td>
                            <select name="<?php echo esc_attr($this->option_key); ?>[button_position]">
                                <?php
                                $positions = ['inherit','left','center','right'];
                                foreach ( $positions as $pos ) {
                                    printf(
                                        '<option value="%s" %s>%s</option>',
                                        esc_attr($pos),
                                        selected( $options['button_position'] ?? 'inherit', $pos, false ),
                                        esc_html( ucfirst($pos) )
                                    );
                                }
                                ?>
                            </select>
                        </td>
                    </tr>

                    <!-- ✅ New Button Text Settings -->
                    <tr>
                        <th><?php esc_html_e( 'Calculate Button Text', 'dakidarts-numerology-core' ); ?></th>
                        <td>
                            <input type="text"
                                   name="<?php echo esc_attr($this->option_key); ?>[calculate_text]"
                                   value="<?php echo esc_attr($options['calculate_text'] ?? 'Calculate'); ?>"
                                   placeholder="<?php esc_attr_e('e.g. Calculate', 'dakidarts-numerology-core'); ?>" />
                        </td>
                    </tr>

                    <tr>
                        <th><?php esc_html_e( 'Try Again Button Text', 'dakidarts-numerology-core' ); ?></th>
                        <td>
                            <input type="text"
                                   name="<?php echo esc_attr($this->option_key); ?>[try_again_text]"
                                   value="<?php echo esc_attr($options['try_again_text'] ?? 'Try Again'); ?>"
                                   placeholder="<?php esc_attr_e('e.g. Try Again', 'dakidarts-numerology-core'); ?>" />
                        </td>
                    </tr>

                </tbody>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>

    <script>
        jQuery(document).ready(function($){
            $('.dakidarts-color-picker').wpColorPicker();
        });
    </script>
    <?php
}

}
