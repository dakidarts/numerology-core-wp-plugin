<?php
/**
 * Dakidarts Numerology Core - Admin Settings Page
 *
 * Handles API key input, endpoint activation toggles, and saving settings.
 *
 * @package Dakidarts_Numerology_Core
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'Dakidarts_Admin_Settings' ) ) {

    class Dakidarts_Admin_Settings {

        private $option_key = 'dakidarts_numerology_core_settings';
        private $api_host   = 'https://the-numerology-api.p.rapidapi.com';

        public function __construct() {
            add_action( 'admin_post_dakidarts_save_settings', [ $this, 'save_settings' ] );
            add_action( 'admin_notices', [ $this, 'render_notices' ] );
        }

        /**
         * Render the settings HTML.
         */
        public function render() {
            $options   = get_option( $this->option_key, [] );
            $api_key   = isset( $options['api_key'] ) ? '******' : '';
            $endpoints = Dakidarts_API::get_endpoints();
            ?>
            <div class="dakidarts-admin-settings">
                <h2><?php esc_html_e( 'Plugin Settings', 'dakidarts-numerology-core' ); ?></h2>

                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                    <?php wp_nonce_field( 'dakidarts_save_settings' ); ?>
                    <input type="hidden" name="action" value="dakidarts_save_settings" />

                    <!-- API Key Section -->
                    <h3><?php esc_html_e( 'API Key', 'dakidarts-numerology-core' ); ?></h3>
                    <p>
                        <input type="password" name="api_key" value="<?php echo esc_attr( $api_key ); ?>"
                               placeholder="<?php esc_attr_e( 'Enter API Key', 'dakidarts-numerology-core' ); ?>"
                               style="width:400px; max-width:100%;" />
                        <?php if ( $api_key ) : ?>
                            <em style="color:#555;"><?php esc_html_e( 'API Key is stored securely.', 'dakidarts-numerology-core' ); ?></em>
                        <?php endif; ?>
                    </p>

                    <!-- Endpoints Section -->
                    <h3><?php esc_html_e( 'Activate Endpoints', 'dakidarts-numerology-core' ); ?></h3>
                    <p><?php esc_html_e( 'Toggle which Numerology endpoints should be active and available via shortcode.', 'dakidarts-numerology-core' ); ?></p>
                    <table class="form-table">
                        <tbody>
                        <?php foreach ( $endpoints as $key => $endpoint ) :
                            $checked   = isset( $options['endpoints'][ $key ] ) ? checked( 1, $options['endpoints'][ $key ], false ) : '';
                            $shortcode = '[dakidarts_numerology endpoint="' . esc_attr( $key ) . '"]';
                            ?>
                            <tr>
                                <th scope="row"><?php echo esc_html( $endpoint['label'] ); ?></th>
                                <td>
                                    <label>
                                        <input type="checkbox" name="endpoints[<?php echo esc_attr( $key ); ?>]" value="1" <?php echo $checked; ?> />
                                        <em style="margin-left:10px; color:#555;"><?php echo esc_html( $shortcode ); ?></em>
                                    </label>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>

                    <?php submit_button( __( 'Save Settings', 'dakidarts-numerology-core' ) ); ?>
                </form>
            </div>
            <?php
        }

        /**
         * Save settings handler.
         */
        public function save_settings() {
            if ( ! current_user_can( 'manage_options' ) ) {
                wp_die( __( 'You are not allowed to perform this action.', 'dakidarts-numerology-core' ) );
            }

            check_admin_referer( 'dakidarts_save_settings' );

            $input = [];
            $message = '';
            $type    = 'success';

            // Save API key securely
            if ( ! empty( $_POST['api_key'] ) ) {
                $api_key = sanitize_text_field( wp_unslash( $_POST['api_key'] ) );
                if ( $this->validate_api_key( $api_key ) ) {
                    $input['api_key'] = Dakidarts_Helpers::encrypt( $api_key, DAKIDARTS_SECRET_KEY );


                    $message = __( 'API Key saved and validated successfully!', 'dakidarts-numerology-core' );
                } else {
                    $message = __( 'Invalid API Key. Please check or subscribe to the API.', 'dakidarts-numerology-core' );
                    $type    = 'error';
                }
            }

            // Save endpoints toggles
            if ( isset( $_POST['endpoints'] ) && is_array( $_POST['endpoints'] ) ) {
                $input['endpoints'] = [];
                foreach ( $_POST['endpoints'] as $key => $value ) {
                    $input['endpoints'][ sanitize_key( $key ) ] = 1;
                }
            }

            update_option( $this->option_key, $input );

            // Store notice in transient so it shows after redirect
            set_transient( 'dakidarts_admin_notice', [ 'message' => $message, 'type' => $type ], 30 );

            wp_safe_redirect( admin_url( 'admin.php?page=dakidarts-numerology-settings' ) );
            exit;
        }

        /**
         * Validate the API key by making a request to the status endpoint.
         */
        private function validate_api_key( $api_key ) {
            $url = $this->api_host . '/status';

            $response = wp_remote_get( $url, [
                'headers' => [
                    'X-RapidAPI-Key' => $api_key,
                    'X-RapidAPI-Host' => 'the-numerology-api.p.rapidapi.com',
                ],
                'timeout' => 15,
            ] );

            if ( is_wp_error( $response ) ) {
                return false;
            }

            $data = json_decode( wp_remote_retrieve_body( $response ), true );
            return isset( $data['status'] ) && $data['status'] === 'API is online';
        }

        /**
         * Render notices (popups) that disappear after 5s.
         */
        public function render_notices() {
            $notice = get_transient( 'dakidarts_admin_notice' );
            if ( ! $notice ) {
                return;
            }

            delete_transient( 'dakidarts_admin_notice' ); // one-time notice

            $class = $notice['type'] === 'error' ? 'notice-error' : 'notice-success';
            ?>
            <div class="notice <?php echo esc_attr( $class ); ?> is-dismissible dakidarts-popup">
                <p><?php echo esc_html( $notice['message'] ); ?></p>
            </div>
            <script>
                setTimeout(function() {
                    document.querySelectorAll('.dakidarts-popup').forEach(function(el) {
                        el.style.display = 'none';
                    });
                }, 5000);
            </script>
            <?php
        }
    }
}

