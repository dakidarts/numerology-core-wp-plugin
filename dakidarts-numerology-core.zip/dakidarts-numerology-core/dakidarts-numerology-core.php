<?php
/**
 * Plugin Name: Dakidarts Numerology Core
 * Plugin URI:  https://dakidarts.com/plugin/numerology-wordpress-plugin/
 * Description: Unlock the full power of numerology in WordPress. Use shortcodes, Gutenberg blocks, and fully customizable forms — all built on the Dakidarts Numerology API.
 * Version:     1.0.0
 * Author:      Dakidarts
 * Author URI:  https://dakidarts.com
 * Text Domain: dakidarts-numerology-core
 * Domain Path: /languages
 * License:     GPL2+
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ---------------------------------------------------
// Display errors for dev (disable on production)
// ---------------------------------------------------
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// ---------------------------------------------------
// Includes - Core Classes
// ---------------------------------------------------
require_once plugin_dir_path( __FILE__ ) . 'includes/helpers.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/class-dakidarts-admin.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/class-dakidarts-api.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/class-dakidarts-shortcodes.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/class-dakidarts-render.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/class-dakidarts-blocks.php';

// ---------------------------------------------------
// Plugin Activation / Deactivation
// ---------------------------------------------------
register_activation_hook( __FILE__, function() {
    if ( ! get_option( 'dakidarts_numerology_core_settings' ) ) {
        add_option( 'dakidarts_numerology_core_settings', [] );
    }
});

register_deactivation_hook( __FILE__, function() {
    // Optional cleanup
});

if ( ! defined( 'DAKIDARTS_PLUGIN_URL' ) ) {
    define( 'DAKIDARTS_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}

if ( ! defined( 'DAKIDARTS_PLUGIN_PATH' ) ) {
    define( 'DAKIDARTS_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'DAKIDARTS_SECRET_KEY' ) ) {
    define( 'DAKIDARTS_SECRET_KEY', 's17f8h2j9k1l4f8h2j9k17' ); // random secret
}

// ---------------------------------------------------
// Enqueue Frontend Assets
// ---------------------------------------------------
function dakidarts_enqueue_frontend_assets() {
    wp_enqueue_style(
        'dakidarts-style',
        plugins_url( 'assets/css/style.css', __FILE__ ),
        [],
        filemtime( plugin_dir_path( __FILE__ ) . 'assets/css/style.css' )
    );

    $style_options = get_option( 'dakidarts_numerology_style_settings', [] );
    $defaults = [
        'form_bg'        => '#ffffff',
        'form_padding'   => '20px',
        'button_bg'      => '#0073aa',
        'button_color'   => '#ffffff',
        'button_radius'  => '10px',
        'button_border'  => '1px solid #0073aa',
        'button_position'=> 'inherit',
    ];
    $styles = wp_parse_args( $style_options, $defaults );

    $button_margin = $styles['button_position'] !== 'inherit' ? '0 auto' : 'initial';

    $custom_css = "
        .dakidarts-form { background: {$styles['form_bg']}; padding: {$styles['form_padding']}; }
        .dakidarts-form button {
            background: {$styles['button_bg']};
            color: {$styles['button_color']};
            border-radius: {$styles['button_radius']};
            border: {$styles['button_border']};
            display: " . ( $styles['button_position'] === 'inherit' ? 'inline-block' : 'block' ) . ";
            margin: {$button_margin};
        }
    ";

    wp_add_inline_style( 'dakidarts-style', $custom_css );
}
add_action( 'wp_enqueue_scripts', 'dakidarts_enqueue_frontend_assets' );

// ---------------------------------------------------
// Enqueue Admin Assets
// ---------------------------------------------------
function dakidarts_enqueue_admin_assets( $hook ) {
    if ( strpos( $hook, 'dakidarts-numerology' ) === false ) return;

    wp_enqueue_style( 'wp-color-picker' );
    wp_enqueue_script( 'wp-color-picker' );

    wp_enqueue_style(
        'dakidarts-admin-style',
        plugins_url( 'assets/css/admin.css', __FILE__ ),
        [],
        filemtime( plugin_dir_path( __FILE__ ) . 'assets/css/admin.css' )
    );
    wp_enqueue_script(
        'dakidarts-admin-js',
        plugins_url( 'assets/js/admin.js', __FILE__ ),
        [ 'jquery', 'wp-color-picker' ],
        filemtime( plugin_dir_path( __FILE__ ) . 'assets/js/admin.js' ),
        true
    );
}
add_action( 'admin_enqueue_scripts', 'dakidarts_enqueue_admin_assets' );

// ---------------------------------------------------
// Initialize Shortcodes & Gutenberg Blocks
// ---------------------------------------------------
if ( class_exists( 'Dakidarts_Shortcodes' ) ) new Dakidarts_Shortcodes();
if ( class_exists( 'Dakidarts_Blocks' ) ) new Dakidarts_Blocks();

// ---------------------------------------------------
// Load Text Domain for Translations
// ---------------------------------------------------
function dakidarts_load_textdomain() {
    load_plugin_textdomain( 'dakidarts-numerology-core', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}
add_action( 'plugins_loaded', 'dakidarts_load_textdomain' );
