<?php
/**
 * Default Numerology Result Template - Dynamic & Admin-Styled
 *
 * Variables expected:
 *   - $response (array|string)
 *   - $template (string)
 *   - $styles (array)
 */

// Ensure $styles is always an array and pull admin settings if empty
$styles = isset($styles) && is_array($styles) ? $styles : get_option('dakidarts_numerology_style_settings', []);

// Form container styles
$form_style = sprintf(
    'background:%s;padding:%s;margin:%s;border-radius:%s;',
    esc_attr($styles['form_bg'] ?? '#fff'),
    esc_attr($styles['form_padding'] ?? '15px'),
    esc_attr($styles['form_margin'] ?? '10px auto'),
    esc_attr($styles['button_radius'] ?? '8px')
);

// -------------------------
// Button texts
// -------------------------
$calculate_text = !empty($styles['calculate_text']) ? $styles['calculate_text'] : __('Calculate', 'dakidarts-numerology-core');
$try_again_text = !empty($styles['try_again_text']) ? $styles['try_again_text'] : __('Try Again', 'dakidarts-numerology-core');

// -------------------------
// Button style mode
// -------------------------
$button_mode = $styles['button_style_mode'] ?? 'inherit';

// -------------------------
// Button inline styles
// -------------------------
$button_inline_style = '';
if ($button_mode === 'custom') {
    $button_inline_style = sprintf(
        'background:%s;color:%s;padding:%s;border:%s %s %s;border-radius:%s;display:block;margin:%s;text-align:center;',
        esc_attr($styles['button_bg'] ?? '#0073aa'),
        esc_attr($styles['button_color'] ?? '#fff'),
        esc_attr($styles['button_padding'] ?? '10px 20px'),
        esc_attr($styles['button_border_width'] ?? '1px'),
        esc_attr($styles['button_border_style'] ?? 'solid'),
        esc_attr($styles['button_border_color'] ?? '#0073aa'),
        esc_attr($styles['button_radius'] ?? '4px'),
        ($styles['button_position'] ?? 'center') === 'center' ? '0 auto' :
        (($styles['button_position'] ?? 'center') === 'right' ? '0 0 0 auto' : '0 0 0 0')
    );
}

/**
 * Recursive function to render API response as nested cards
 */
function dakidarts_render_response($data, $level = 0, $styles = []) {
    if (!is_array($data)) return '<p>' . esc_html($data) . '</p>';

    $html = '';
    foreach ($data as $key => $value) {
        $heading = esc_html(ucwords(str_replace(['_', '-'], ' ', $key)));

        $bg = $level === 0
            ? ($styles['form_bg'] ?? '#fefefe')
            : ($level === 1
                ? ($styles['form_bg'] ? adjust_brightness($styles['form_bg'], -10) : '#f9f9f9')
                : ($styles['form_bg'] ? adjust_brightness($styles['form_bg'], -20) : '#efefef'));

        $html .= '<div class="dakidarts-card" style="background:' . esc_attr($bg) . ';padding:12px 15px;margin:10px 0;border-radius:' . esc_attr($styles['button_radius'] ?? '6px') . ';box-shadow:0 2px 6px rgba(0,0,0,0.05);">';
        $html .= '<h4 style="margin:0 0 8px;color:' . esc_attr($styles['button_bg'] ?? '#0073aa') . ';font-size:16px;">' . $heading . '</h4>';
        $html .= is_array($value) ? dakidarts_render_response($value, $level + 1, $styles) : '<p style="margin:0;color:#333;">' . esc_html($value) . '</p>';
        $html .= '</div>';
    }
    return $html;
}

/**
 * Helper to adjust hex color brightness
 */
function adjust_brightness($hex, $steps) {
    $steps = max(-255, min(255, $steps));
    $hex   = str_replace('#', '', $hex);
    if (strlen($hex) === 3) $hex = str_repeat($hex[0], 2) . str_repeat($hex[1], 2) . str_repeat($hex[2], 2);
    $r = max(0, min(255, hexdec(substr($hex, 0, 2)) + $steps));
    $g = max(0, min(255, hexdec(substr($hex, 2, 2)) + $steps));
    $b = max(0, min(255, hexdec(substr($hex, 4, 2)) + $steps));
    return '#' . str_pad(dechex($r), 2, '0', STR_PAD_LEFT) . str_pad(dechex($g), 2, '0', STR_PAD_LEFT) . str_pad(dechex($b), 2, '0', STR_PAD_LEFT);
}
?>

<div class="dakidarts-result dakidarts-result-<?php echo esc_attr($template); ?>" style="<?php echo esc_attr($form_style); ?>">

    <?php if (!empty($response)) : ?>
        <?php echo dakidarts_render_response($response, 0, $styles); ?>
    <?php else : ?>
        <p><?php esc_html_e('No data returned from the API.', 'dakidarts-numerology-core'); ?></p>
    <?php endif; ?>

    <div class="dakidarts-button-wrapper">
        <button type="button" class="button dakidarts-try-again" <?php echo $button_mode === 'custom' ? 'style="' . esc_attr($button_inline_style) . '"' : ''; ?>>
            <?php echo esc_html($try_again_text); ?>
        </button>
    </div>
</div>

<style>
.dakidarts-result { font-family: Arial, sans-serif; color: #333; line-height:1.5; }
.dakidarts-result p { margin-bottom:6px; }
.dakidarts-result h4 { font-weight:600; }
.dakidarts-card p { margin:0; }
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const tryAgainBtn = document.querySelector('.dakidarts-try-again');
    if (tryAgainBtn) {
        tryAgainBtn.addEventListener('click', function(e) {
            e.preventDefault();
            window.location.href = window.location.href.split('?')[0]; // clean reload
        });
    }
});
</script>
