<?php
/**
 * Gutenberg Block Template
 *
 * Supports admin styling for forms rendered via blocks
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Same style logic as form-default
$styles = get_option( 'dakidarts_numerology_style_settings', [] );
$default_styles = [
    'form_bg'        => '#fff',
    'form_padding'   => '10px',
    'form_margin'    => '0',
    'button_bg'      => '#0073aa',
    'button_color'   => '#fff',
    'button_padding' => '10px 20px',
    'button_border'  => '1px solid #0073aa',
    'button_position'=> 'inherit'
];

$styles = wp_parse_args( $styles, $default_styles );
$form_style   = sprintf( 'background:%s;padding:%s;margin:%s;', esc_attr( $styles['form_bg'] ), esc_attr( $styles['form_padding'] ), esc_attr( $styles['form_margin'] ) );
$button_style = sprintf(
    'background:%s;color:%s;padding:%s;border:%s;display:block;margin:%s;',
    esc_attr( $styles['button_bg'] ),
    esc_attr( $styles['button_color'] ),
    esc_attr( $styles['button_padding'] ),
    esc_attr( $styles['button_border'] ),
    $styles['button_position'] === 'inherit' ? 'initial' : '0 auto'
);
?>

<form method="post" class="dakidarts-form dakidarts-block-form" style="<?php echo esc_attr( $form_style ); ?>">
    <?php foreach ( $params as $param ) : ?>
        <p>
            <label for="<?php echo esc_attr( $param ); ?>">
                <?php echo esc_html( ucfirst( str_replace( '_', ' ', $param ) ) ); ?>:
            </label>
            <input type="text" name="<?php echo esc_attr( $param ); ?>" required />
        </p>
    <?php endforeach; ?>

    <input type="hidden" name="dakidarts_endpoint" value="<?php echo esc_attr( $endpoint ); ?>" />
    <button type="submit" name="dakidarts_submit" class="dakidarts-submit" style="<?php echo esc_attr( $button_style ); ?>">
        <?php esc_html_e( 'Calculate', 'dakidarts-numerology-core' ); ?>
    </button>
</form>
