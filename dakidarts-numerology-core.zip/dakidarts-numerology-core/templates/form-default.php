<?php
/**
 * Default Numerology Form Template - Dynamic & Admin-Styled
 *
 * Variables expected:
 *   - $endpoint (string)
 *   - $params (array)
 *   - $param_desc (array)   <-- NEW: descriptions for each param
 *   - $styles (array)
 *   - $template (string, optional)
 */

$styles      = isset($styles) && is_array($styles) ? $styles : get_option('dakidarts_numerology_style_settings', []);
$params      = isset($params) && is_array($params) ? $params : [];
$param_desc  = isset($param_desc) && is_array($param_desc) ? $param_desc : [];
$endpoint    = $endpoint ?? '';
$template    = $template ?? 'default';

// Form container styles
$form_style = sprintf(
    'background:%s;padding:%s;margin:%s;border-radius:%s;',
    esc_attr($styles['form_bg'] ?? '#fff'),
    esc_attr($styles['form_padding'] ?? '15px'),
    esc_attr($styles['form_margin'] ?? '10px auto'),
    esc_attr($styles['form_radius'] ?? '8px')
);

// Button text & style mode
$button_text = !empty($styles['calculate_text']) ? $styles['calculate_text'] : __('Calculate', 'dakidarts-numerology-core');
$button_mode = $styles['button_style_mode'] ?? 'inherit';

// Button inline styles
$button_inline_style = '';
if ($button_mode === 'custom') {
    $button_inline_style = sprintf(
        'background:%s;color:%s;padding:%s;border:%s %s %s;border-radius:%s;display:block;margin:%s;text-align:center;',
        esc_attr($styles['button_bg'] ?? '#0073aa'),
        esc_attr($styles['button_color'] ?? '#fff'),
        esc_attr($styles['button_padding'] ?? '10px 20px'),
        esc_attr($styles['button_border_width'] ?? '1px'),
        esc_attr($styles['button_border_style'] ?? 'solid'),
        esc_attr($styles['button_border_color'] ?? '#0073aa'),
        esc_attr($styles['button_radius'] ?? '4px'),
        ($styles['button_position'] ?? 'center') === 'center' ? '0 auto' :
        (($styles['button_position'] ?? 'center') === 'right' ? '0 0 0 auto' : '0 0 0 0')
    );
}
?>

<form method="post" action="<?php echo esc_url(get_permalink()); ?>" class="dakidarts-form dakidarts-form-<?php echo esc_attr($template); ?>" style="<?php echo esc_attr($form_style); ?>">
    <?php if (!empty($params)) : ?>
        <?php foreach ($params as $param) : ?>
            <p>
                <label for="<?php echo esc_attr($param); ?>">
                    <?php echo esc_html(ucfirst(str_replace('_', ' ', $param))); ?>:
                </label>
                <input type="text" name="<?php echo esc_attr($param); ?>" required />
                <?php if (!empty($param_desc[$param])) : ?>
                    <span class="dakidarts-param-desc"><?php echo esc_html($param_desc[$param]); ?></span>
                <?php endif; ?>
            </p>
        <?php endforeach; ?>
    <?php endif; ?>

    <input type="hidden" name="dakidarts_endpoint" value="<?php echo esc_attr($endpoint); ?>" />
    <button type="submit" name="dakidarts_submit" class="dakidarts-submit" <?php echo $button_mode === 'custom' ? 'style="' . esc_attr($button_inline_style) . '"' : ''; ?>>
        <?php echo esc_html($button_text); ?>
    </button>
</form>

<style>
.dakidarts-form input[type="text"] {
    width: 100%;
    padding: 8px;
    margin: 5px 0 4px 0; /* reduce bottom margin to fit description */
    box-sizing: border-box;
    border: 1px solid #ccc;
    border-radius: 4px;
}
.dakidarts-form label {
    font-weight: 600;
    margin-bottom: 4px;
    display: block;
}
.dakidarts-param-desc {
    display: block;
    font-style: italic;
    font-size: 0.9em;
    color: #555;
    margin-bottom: 8px;
    font-family: inherit; /* use default theme font */
}
</style>
