jQuery(document).ready(function($){
    $('.dakidarts-numerology-form').on('submit', function(e){
        e.preventDefault();

        const $form = $(this);
        const endpoint = $form.data('endpoint');
        const formData = $form.serialize();

        $form.next('.dakidarts-result').html('<p>Calculating...</p>');

        $.post(DakidartsAjax.ajax_url, {
            action: 'dakidarts_numerology_calculate',
            endpoint: endpoint,
            data: formData,
            _ajax_nonce: DakidartsAjax.nonce
        }, function(response){
            if(response.success){
                $form.next('.dakidarts-result').html(response.data.html);
            } else {
                $form.next('.dakidarts-result').html('<p>Error: ' + response.data + '</p>');
            }
        });
    });
});
