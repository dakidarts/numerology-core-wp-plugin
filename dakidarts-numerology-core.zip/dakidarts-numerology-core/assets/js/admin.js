// ---------------------------------------------------
// Dakidarts Numerology Core - Admin JS
// ---------------------------------------------------

document.addEventListener('DOMContentLoaded', function () {
    // -------------------------
    // Tab switching
    // -------------------------
    const tabs = document.querySelectorAll('.dakidarts-nav-tab');
    const tabContents = document.querySelectorAll('.dakidarts-tab-content');

    if (tabs.length) {
        tabs.forEach(tab => {
            tab.addEventListener('click', function (e) {
                e.preventDefault();

                // Remove active class
                tabs.forEach(t => t.classList.remove('nav-tab-active'));
                tabContents.forEach(c => c.style.display = 'none');

                // Activate current tab
                this.classList.add('nav-tab-active');
                const target = this.getAttribute('data-tab');
                const content = document.getElementById(target);
                if (content) content.style.display = 'block';
            });
        });

        // Activate first tab by default
        tabs[0].click();
    }

    // -------------------------
    // API Key save button feedback
    // -------------------------
    const apiKeyInput = document.getElementById('dakidarts_api_key');
    const saveButton = document.querySelector('.dakidarts-save-btn');

    if (apiKeyInput && saveButton) {
        saveButton.addEventListener('click', function () {
            saveButton.disabled = true;
            saveButton.textContent = 'Saving...';
            setTimeout(() => {
                saveButton.textContent = 'Saved!';
                saveButton.disabled = false;
            }, 1000);
        });
    }

    // -------------------------
    // Endpoint toggle switches
    // -------------------------
    const toggles = document.querySelectorAll('.dakidarts-endpoint-toggle');

    toggles.forEach(toggle => {
        toggle.addEventListener('change', function () {
            const statusText = this.nextElementSibling;
            if (statusText) {
                statusText.textContent = this.checked ? 'Enabled' : 'Disabled';
            }
        });
    });

    // -------------------------
    // Optional: live shortcode preview
    // -------------------------
    const shortcodePreview = document.getElementById('dakidarts_shortcode_preview');
    const endpointSelect = document.querySelectorAll('.dakidarts-endpoint-toggle');

    if (shortcodePreview) {
        endpointSelect.forEach(input => {
            input.addEventListener('change', function () {
                const endpoint = this.getAttribute('data-endpoint');
                shortcodePreview.textContent = `[dakidarts_numerology endpoint="${endpoint}"]`;
            });
        });
    }
});
