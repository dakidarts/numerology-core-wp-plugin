<?php
/**
 * Dakidarts Numerology Core - Uninstall
 *
 * Cleans up all plugin options, styles, and transient data on uninstall.
 *
 * @package Dakidarts_Numerology_Core
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

/**
 * Delete plugin options and transients
 */

// Core settings (API key, endpoint toggles)
delete_option( 'dakidarts_numerology_core_settings' );

// Style settings (form and button styles)
delete_option( 'dakidarts_numerology_style_settings' );

// Transients (admin notices)
delete_transient( 'dakidarts_admin_notice' );

/**
 * Multisite cleanup
 */
if ( is_multisite() ) {
    global $wpdb;
    $blog_ids = $wpdb->get_col( "SELECT blog_id FROM $wpdb->blogs" );

    foreach ( $blog_ids as $blog_id ) {
        switch_to_blog( $blog_id );
        delete_option( 'dakidarts_numerology_core_settings' );
        delete_option( 'dakidarts_numerology_style_settings' );
        delete_transient( 'dakidarts_admin_notice' );
        restore_current_blog();
    }

    // Delete network-wide options (if any)
    delete_site_option( 'dakidarts_numerology_core_settings' );
    delete_site_option( 'dakidarts_numerology_style_settings' );
}

/**
 * Hook for future Pro version cleanup
 * Allows Pro version to add its own cleanup logic without modifying this file
 */
do_action( 'dakidarts_numerology_uninstall' );

/**
 * Optional: clean up custom tables or files if ever added
 */
// global $wpdb;
// $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}dakidarts_numerology_logs" );

/**
 * Optional: clean up uploaded plugin data (if any future uploads occur)
 */
// $upload_dir = wp_upload_dir();
// $plugin_uploads = trailingslashit( $upload_dir['basedir'] ) . 'dakidarts-numerology/';
// if ( is_dir( $plugin_uploads ) ) {
//     // Recursively delete directory
//     $files = new RecursiveIteratorIterator(
//         new RecursiveDirectoryIterator( $plugin_uploads, RecursiveDirectoryIterator::SKIP_DOTS ),
//         RecursiveIteratorIterator::CHILD_FIRST
//     );
//     foreach ( $files as $file ) {
//         $file->isDir() ? rmdir( $file->getRealPath() ) : unlink( $file->getRealPath() );
//     }
//     rmdir( $plugin_uploads );
// }

